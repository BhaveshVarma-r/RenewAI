"""Tests for agent modules (non-API tests)."""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


def test_schemas_creation():
    """Test that all Pydantic models can be created."""
    from schemas.models import (
        PolicyData, PropensityScore, ExecutionPlan,
        CritiqueResult, ComplianceResult, AuditLogEntry,
        OrchestratorState, SafetyGateResult, PlannerLoopState,
    )

    policy = PolicyData(
        policy_id="TEST001", customer_id="CUST001", customer_name="Test User",
        premium_amount=10000.0, due_date="2025-12-01", grace_period_days=30,
        status="active", risk_tier="low", language_preference="english",
        channel_preference="email", contact_phone="9876543210",
        contact_email="test@test.com", preferred_contact_time="morning",
        payment_history=["on_time"], emi_eligible=False, sum_assured=500000.0,
    )
    assert policy.policy_id == "TEST001"

    critique = CritiqueResult(
        verdict="APPROVED", score=8.0, tone_score=8.5,
        language_quality_score=9.0, factual_accuracy=True,
        hallucination_detected=False, feedback="Good quality.",
    )
    assert critique.verdict == "APPROVED"

    state = OrchestratorState(
        policy_id="TEST001", customer_id="CUST001",
        trigger_type="due_date",
    )
    assert state.current_step == "init"


def test_irdai_rules():
    """Test IRDAI rule functions."""
    from config.irdai_rules import IRDAI_RULES

    assert len(IRDAI_RULES) > 10

    # Test AI identity check
    ai_rule = next(r for r in IRDAI_RULES if r["name"] == "ai_identity_declared")
    assert ai_rule["check_fn"]("This is an AI-generated message") == True
    assert ai_rule["check_fn"]("Hello customer") == False

    # Test guaranteed returns check
    returns_rule = next(r for r in IRDAI_RULES if r["name"] == "no_guaranteed_returns_claim")
    assert returns_rule["check_fn"]("Normal insurance message") == True
    assert returns_rule["check_fn"]("guaranteed returns of 20%") == False
