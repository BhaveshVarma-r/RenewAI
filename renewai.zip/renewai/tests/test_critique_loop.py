"""Tests for the planner critique loop."""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


def test_planner_loop_state():
    """Test PlannerLoopState model."""
    from schemas.models import PlannerLoopState, PolicyData, PropensityScore

    policy = PolicyData(
        policy_id="TEST001", customer_id="CUST001", customer_name="Test User",
        premium_amount=10000.0, due_date="2025-12-01", grace_period_days=30,
        status="active", risk_tier="low", language_preference="english",
        channel_preference="email", contact_phone="9876543210",
        contact_email="test@test.com", preferred_contact_time="morning",
        payment_history=["on_time"], emi_eligible=False, sum_assured=500000.0,
    )

    propensity = PropensityScore(
        lapse_probability=0.15, risk_level="low",
        key_factors=["Good payment history"],
        recommended_channel="email", recommended_time="morning",
        emi_recommended=False,
    )

    state = PlannerLoopState(policy_data=policy, propensity_score=propensity)
    assert state.retry_count == 0
    assert state.escalation_flag == False
