"""Unit tests for mock services."""

import pytest
import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


def test_crm_client():
    from mock_services.crm import MockCRMClient
    crm = MockCRMClient()

    # Test get_policy
    policy = crm.get_policy("POL001")
    assert policy is not None
    assert policy.policy_id == "POL001"
    assert policy.customer_name == "Rajesh Kumar"
    assert policy.risk_tier == "low"
    assert policy.language_preference == "hindi"

    # Test missing policy
    assert crm.get_policy("NONEXISTENT") is None

    # Test all policies exist
    all_policies = crm.get_all_policies()
    assert len(all_policies) >= 25

    # Test risk tier coverage
    tiers = {p.risk_tier for p in all_policies}
    assert tiers == {"low", "medium", "high", "critical"}

    # Test language coverage
    langs = {p.language_preference for p in all_policies}
    assert len(langs) >= 9


def test_cloud_dlp():
    from mock_services.cloud_dlp import MockCloudDLP
    dlp = MockCloudDLP()

    # Test Aadhaar masking
    text = "Aadhaar: 1234 5678 9012"
    masked, findings = dlp.mask_pii(text)
    assert "XXXX-XXXX-9012" in masked
    assert len(findings) > 0

    # Test PAN masking
    text2 = "PAN: ABCDE1234F"
    masked2, findings2 = dlp.mask_pii(text2)
    assert "XXXXX" in masked2

    # Test phone masking
    text3 = "Phone: 9876543210"
    masked3, findings3 = dlp.mask_pii(text3)
    assert "XXXXX" in masked3

    # Test email masking
    text4 = "Email: test@example.com"
    masked4, findings4 = dlp.mask_pii(text4)
    assert "***@" in masked4


def test_redis_cache():
    from mock_services.redis_cache import MockRedisClient
    redis = MockRedisClient()

    # Test set/get
    redis.set("test_key", "test_value")
    assert redis.get("test_key") == "test_value"

    # Test delete
    redis.delete("test_key")
    assert redis.get("test_key") is None

    # Test rate limiting
    assert redis.check_rate_limit("CUST001", "email") == True
    assert redis.check_rate_limit("CUST001", "email") == True
    assert redis.check_rate_limit("CUST001", "email") == True
    assert redis.check_rate_limit("CUST001", "email") == False  # 4th should fail

    # Test session
    redis.set_session("sess1", {"intent": "pay"})
    session = redis.get_session("sess1")
    assert session["intent"] == "pay"


def test_vertex_ai():
    loop = asyncio.new_event_loop()
    from mock_services.vertex_ai import MockPropensityScorer
    scorer = MockPropensityScorer()

    result = loop.run_until_complete(scorer.get_lapse_score(
        "POL001", ["on_time", "on_time"], 45, "low", 12000
    ))
    assert result["lapse_probability"] < 0.3
    assert result["risk_level"] == "low"

    result2 = loop.run_until_complete(scorer.get_lapse_score(
        "POL012", ["missed", "missed", "missed"], 5, "critical", 60000
    ))
    assert result2["lapse_probability"] > 0.8
    assert result2["risk_level"] == "critical"
    loop.close()


def test_exotel_dnd():
    from mock_services.exotel import MockExotelClient
    exotel = MockExotelClient()

    # DND is deterministic — should be consistent
    result1 = exotel.check_dnd_status("9876543210")
    result2 = exotel.check_dnd_status("9876543210")
    assert result1 == result2


def test_vector_search():
    import asyncio
    from mock_services.vector_search import MockVectorSearch
    
    async def run_test():
        vs = MockVectorSearch()
        await vs.async_init()

        results = await vs.similarity_search("can't afford premium", k=3)
        assert len(results) > 0
        assert "response" in results[0]

        # Test add document
        vs.add_document("test objection", {"response": "test response"})
    
    asyncio.run(run_test())


def test_firestore():
    from mock_services.firestore import MockFirestoreClient
    fs = MockFirestoreClient()

    fs.set_document("test_col", "doc1", {"name": "test", "value": 123})
    doc = fs.get_document("test_col", "doc1")
    assert doc is not None
    assert doc["name"] == "test"

    fs.update_document("test_col", "doc1", {"value": 456})
    doc2 = fs.get_document("test_col", "doc1")
    assert doc2["value"] == 456
