"""Tests for the safety gate middleware."""

import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


def test_distress_detector():
    from middleware.distress_detector import DistressDetector
    dd = DistressDetector()

    # Should detect English distress
    result = dd.check("I can't take this anymore, I want to die", "english")
    assert result["distress_detected"] == True
    assert result["severity"] == "high"

    # Should detect Hindi distress
    result2 = dd.check("marna chahta hoon", "hindi")
    assert result2["distress_detected"] == True

    # Should not detect in normal text
    result3 = dd.check("I want to pay my premium", "english")
    assert result3["distress_detected"] == False

    # Should handle empty text
    result4 = dd.check("", "english")
    assert result4["distress_detected"] == False


def test_compliance_checker():
    from datetime import datetime
    from middleware.compliance_checker import ComplianceChecker
    checker = ComplianceChecker()

    # Message with all disclosures
    good_msg = "This is an AI-generated message. Reply STOP to opt out. Grievance: 1800-123-4567."
    result = checker.check(good_msg)
    assert result.irdai_disclosure_present == True
    assert result.opt_out_present == True

    # If outside business hours (9PM-9AM), timing rule will cause BLOCK — that's expected behavior
    hour = datetime.now().hour
    if 9 <= hour < 21:
        assert result.verdict == "PASS"
    else:
        # Timing violation is expected outside business hours
        assert result.verdict in ("BLOCK", "FAIL")

    # Mis-selling should always block regardless of time
    bad_msg = "guaranteed returns of 20% with zero risk!"
    result2 = checker.check(bad_msg)
    assert result2.verdict == "BLOCK"
    assert result2.mis_selling_detected == True


def test_safety_gate():
    from datetime import datetime
    loop = asyncio.new_event_loop()
    from middleware.safety_gate import SafetyGate
    gate = SafetyGate()

    hour = datetime.now().hour
    is_business_hours = 9 <= hour < 21

    # Normal content
    result = loop.run_until_complete(gate.process(
        "Dear customer, your premium is due. This is an AI-assisted message. Reply STOP. Grievance: 1800-123-4567.",
        language="english",
    ))
    if is_business_hours:
        assert result.passed == True
    else:
        # Outside business hours, timing violation blocks
        assert result.passed == False

    # Content with distress should always escalate
    result2 = loop.run_until_complete(gate.process(
        "I want to die, I can't take this anymore",
        language="english",
    ))
    assert result2.escalate_human == True
    loop.close()
